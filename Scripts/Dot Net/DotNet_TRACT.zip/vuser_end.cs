//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 
//---------------------------------------------

namespace Script
{
    public partial class VuserClass
    {
        public int vuser_end()
        {
            return 0;
        }
    }
}
