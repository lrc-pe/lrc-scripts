//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 1203
//---------------------------------------------

namespace Script {
    using ClassLibrary1;
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    
    
    public partial class VuserClass {
        
        private Class1 Class1_1;
        
        private String StringRetVal;
        
        private Int32 Int32RetVal;
        
        private struct_test st_1;
        
        private struct_test st_2;
        
        private struct_test struct_test_2;
        
        private class_test class_test_1;
        
        private class_test class_test_2;
        
        private class_test class_test_3;
        
        private struct_test outTest_1;
        
        private class_test outTest_2;
        
        private Int32[] nums_1;
        
        private Int32[] Int32Array_1;
        
        private class_test class_test_4;
        
        private class_test class_test_5;
        
        private class_test class_test_6;
        
        private class_test class_test_7;
        
        private class_test class_test_8;
        
        private class_test[] structs_1;
        
        private class_test[] class_testArray_1;
        
        private struct_test[] structs_2;
        
        private struct_test structs_3;
        
        private struct_test structs_4;
        
        private struct_test structs_5;
        
        private struct_test structs_6;
        
        private struct_test structs_7;
        
        private struct_test[] retArr_1;
        
        private class_test class_test_9;
        
        private class_test class_test_10;
        
        private class_test class_test_11;
        
        private class_test class_test_12;
        
        private class_test class_test_13;
        
        private class_test[] structs_8;
        
        private class_test[] retArr_2;
        
        private struct_test[,] structs_9;
        
        private struct_test structs_10;
        
        private struct_test[,] outArr_1;
        
        private struct_test[,] struct_testArray_1;
        
        private class_test class_test_14;
        
        private struct_test[,] structs_11;
        
        private struct_test[,] outArr_2;
        
        private struct_test[,] struct_testArray_2;
        
        private class_test outTest_3;
        
        private class_test class_test_15;
        
        private class_test class_test_16;
        
        private class_test class_test_17;
        
        private class_test class_test_18;
        
        private class_test class_test_19;
        
        private class_test class_test_20;
        
        private class_test[] structs_12;
        
        private class_test[] class_testArray_2;
    }
}
